
package com.tattantat.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val BrandGreen = Color(0xFF08A65A)
private val HeaderGreen = Color(0xFF056B3A)
private val HeaderGreen2 = Color(0xFF075B36)
private val Bg = Color(0xFFF6F8F7)
private val TextDark = Color(0xFF1E2A25)
private val Muted = Color(0xFF7A8580)
private val White = Color.White

data class Category(val name: String, val icon: @Composable () -> Unit)
data class Product(
    val title: String,
    val price: String,
    val location: String,
    val icon: @Composable () -> Unit
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { TatTanTatApp() }
    }
}

@Composable
fun TatTanTatApp() {
    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = BrandGreen,
            secondary = HeaderGreen,
            background = Bg,
            surface = White
        )
    ) {
        var tab by remember { mutableIntStateOf(0) }

        Scaffold(
            containerColor = Bg,
            bottomBar = {
                BottomNav(selected = tab, onSelected = { tab = it })
            }
        ) { padding ->
            Box(Modifier.fillMaxSize().padding(padding)) {
                when (tab) {
                    0 -> Home()
                    1 -> MyListings()
                    2 -> Sell()
                    3 -> Messages()
                    else -> Account()
                }
            }
        }
    }
}

@Composable
fun Header() {
    Column(
        Modifier
            .fillMaxWidth()
            .background(HeaderGreen)
            .padding(horizontal = 14.dp, vertical = 10.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Surface(
                modifier = Modifier.size(42.dp),
                shape = RoundedCornerShape(12.dp),
                color = White
            ) {
                Image(
                    painter = painterResource(id = R.drawable.tattantat_icon),
                    contentDescription = "Tất Tần Tật",
                    modifier = Modifier.padding(5.dp),
                    contentScale = ContentScale.Fit
                )
            }
            Spacer(Modifier.width(8.dp))
            Column(Modifier.weight(1f)) {
                Text("Tất Tần Tật", color = White, fontSize = 18.sp, fontWeight = FontWeight.ExtraBold)
                Text("Mua bán mọi thứ, gần bạn", color = Color.White.copy(alpha = .78f), fontSize = 10.sp)
            }
            IconButton(onClick = {}) { Icon(Icons.Default.FavoriteBorder, null, tint = White) }
            IconButton(onClick = {}) { Icon(Icons.Default.NotificationsNone, null, tint = White) }
        }

        Spacer(Modifier.height(8.dp))

        Surface(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            color = White
        ) {
            Row(
                Modifier.padding(horizontal = 14.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Default.Search, null, tint = TextDark)
                Spacer(Modifier.width(10.dp))
                Text("Tìm sản phẩm...", color = Muted, fontSize = 16.sp)
            }
        }
    }
}

@Composable
fun Home() {
    val categories = listOf(
        "Bất động sản" to Icons.Default.HomeWork,
        "Xe cộ" to Icons.Default.DirectionsCar,
        "Việc làm" to Icons.Default.Work,
        "Điện tử" to Icons.Default.PhoneIphone,
        "Thú cưng" to Icons.Default.Pets,
        "Thời trang" to Icons.Default.Checkroom,
        "Gia dụng" to Icons.Default.Weekend
    )

    val products = listOf(
        Product("Nhà trọ hẻm 772 sạch đẹp giá rẻ", "3,6 triệu/tháng", "Quy Nhơn", { Icon(Icons.Default.Home, null, tint = BrandGreen) }),
        Product("iPhone 16 Plus Zin Ốc", "18.900.000đ", "Quy Nhơn", { Icon(Icons.Default.PhoneIphone, null, tint = BrandGreen) }),
        Product("Căn hộ dịch vụ mini", "2,4 triệu/tháng", "Quy Nhơn", { Icon(Icons.Default.Apartment, null, tint = BrandGreen) }),
        Product("Nhà cho thuê nguyên căn", "6 triệu/tháng", "Quy Nhơn", { Icon(Icons.Default.House, null, tint = BrandGreen) }),
        Product("MacBook Air M1", "11.000.000đ", "Quy Nhơn", { Icon(Icons.Default.LaptopMac, null, tint = BrandGreen) }),
        Product("Honda Vision 2022", "28.000.000đ", "Quy Nhơn", { Icon(Icons.Default.TwoWheeler, null, tint = BrandGreen) })
    )

    Column(Modifier.fillMaxSize().background(Bg)) {
        Header()

        LazyVerticalGrid(
            columns = GridCells.Fixed(2),
            contentPadding = PaddingValues(12.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item(span = { androidx.compose.foundation.lazy.grid.GridItemSpan(2) }) {
                CategoryRow(categories)
            }

            item(span = { androidx.compose.foundation.lazy.grid.GridItemSpan(2) }) {
                Row(
                    Modifier.fillMaxWidth().padding(top = 2.dp),
                    horizontalArrangement = Arrangement.spacedBy(24.dp)
                ) {
                    Text("Dành cho bạn", fontSize = 19.sp, fontWeight = FontWeight.Bold, color = TextDark)
                    Text("Gần bạn", fontSize = 18.sp, color = Muted)
                    Text("Mới nhất", fontSize = 18.sp, color = Muted)
                }
            }

            items(products) { ProductCard(it) }
        }
    }
}

@Composable
fun CategoryRow(items: List<Pair<String, androidx.compose.ui.graphics.vector.ImageVector>>) {
    Row(
        Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(vertical = 8.dp),
        horizontalArrangement = Arrangement.spacedBy(18.dp)
    ) {
        items.forEach { (name, icon) ->
            Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.width(70.dp)) {
                Surface(
                    modifier = Modifier.size(50.dp),
                    shape = CircleShape,
                    color = White,
                    shadowElevation = 1.dp
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(icon, null, tint = BrandGreen, modifier = Modifier.size(27.dp))
                    }
                }
                Spacer(Modifier.height(5.dp))
                Text(name, fontSize = 11.sp, color = TextDark, maxLines = 2)
            }
        }
    }
}

@Composable
fun ProductCard(p: Product) {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = White),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column {
            Box(
                Modifier.fillMaxWidth().height(145.dp).background(Color(0xFFEFF5F1)),
                contentAlignment = Alignment.Center
            ) {
                Surface(
                    modifier = Modifier.size(68.dp),
                    shape = CircleShape,
                    color = White
                ) {
                    Box(contentAlignment = Alignment.Center) { p.icon() }
                }
                IconButton(
                    onClick = {},
                    modifier = Modifier.align(Alignment.TopEnd)
                ) {
                    Icon(Icons.Default.FavoriteBorder, null, tint = White)
                }
            }
            Column(Modifier.padding(11.dp)) {
                Text(p.title, fontSize = 14.sp, color = TextDark, maxLines = 2, fontWeight = FontWeight.Medium)
                Spacer(Modifier.height(6.dp))
                Text(p.price, fontSize = 16.sp, color = BrandGreen, fontWeight = FontWeight.ExtraBold)
                Spacer(Modifier.height(4.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.LocationOn, null, tint = Muted, modifier = Modifier.size(14.dp))
                    Spacer(Modifier.width(2.dp))
                    Text(p.location, fontSize = 11.sp, color = Muted)
                }
            }
        }
    }
}

@Composable
fun BottomNav(selected: Int, onSelected: (Int) -> Unit) {
    val items = listOf(
        "Trang chủ" to Icons.Default.Home,
        "Quản lý tin" to Icons.Default.Sell,
        "Đăng tin" to Icons.Default.Add,
        "Liên hệ" to Icons.Default.ChatBubbleOutline,
        "Tài khoản" to Icons.Default.Person
    )

    NavigationBar(
        containerColor = HeaderGreen2,
        contentColor = White,
        tonalElevation = 0.dp
    ) {
        items.forEachIndexed { i, item ->
            if (i == 2) {
                NavigationBarItem(
                    selected = selected == i,
                    onClick = { onSelected(i) },
                    icon = {
                        Surface(
                            modifier = Modifier.size(52.dp),
                            shape = CircleShape,
                            color = BrandGreen
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(item.second, null, tint = White, modifier = Modifier.size(30.dp))
                            }
                        }
                    },
                    label = { Text(item.first, color = White, fontSize = 10.sp) },
                    colors = NavigationBarItemDefaults.colors(
                        indicatorColor = Color.Transparent,
                        selectedIconColor = White,
                        unselectedIconColor = White
                    )
                )
            } else {
                NavigationBarItem(
                    selected = selected == i,
                    onClick = { onSelected(i) },
                    icon = { Icon(item.second, null, modifier = Modifier.size(22.dp)) },
                    label = { Text(item.first, fontSize = 10.sp) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = BrandGreen,
                        unselectedIconColor = White.copy(alpha = .75f),
                        selectedTextColor = White,
                        unselectedTextColor = White.copy(alpha = .75f),
                        indicatorColor = Color.White.copy(alpha = .10f)
                    )
                )
            }
        }
    }
}

@Composable
fun Top(title: String) {
    Row(
        Modifier.fillMaxWidth().background(HeaderGreen).padding(16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(Icons.Default.ArrowBack, null, tint = White)
        Spacer(Modifier.width(12.dp))
        Text(title, fontSize = 20.sp, fontWeight = FontWeight.Bold, color = White)
    }
}

@Composable
fun MyListings() {
    SimplePage("Quản lý tin", listOf("iPhone 16 Plus", "Nhà cho thuê", "MacBook Air M1", "Honda Vision"))
}

@Composable
fun Sell() {
    Column(Modifier.fillMaxSize().background(Bg)) {
        Top("Đăng tin")
        Column(
            Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Card(
                Modifier.fillMaxWidth().height(150.dp),
                shape = RoundedCornerShape(18.dp)
            ) {
                Column(
                    Modifier.fillMaxSize(),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Icon(Icons.Default.AddAPhoto, null, tint = BrandGreen, modifier = Modifier.size(34.dp))
                    Text("Thêm ảnh sản phẩm", fontWeight = FontWeight.Bold)
                    Text("Tối đa 12 ảnh", fontSize = 12.sp, color = Muted)
                }
            }
            Field("Tiêu đề sản phẩm")
            Field("Giá bán")
            Field("Danh mục")
            Field("Mô tả chi tiết")
            Button(
                onClick = {},
                modifier = Modifier.fillMaxWidth().height(52.dp),
                shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.buttonColors(containerColor = BrandGreen)
            ) { Text("Đăng tin", fontWeight = FontWeight.Bold) }
        }
    }
}

@Composable
fun Field(label: String) {
    OutlinedTextField(
        value = "",
        onValueChange = {},
        modifier = Modifier.fillMaxWidth(),
        placeholder = { Text(label) },
        shape = RoundedCornerShape(14.dp),
        singleLine = true
    )
}

@Composable
fun Messages() {
    SimplePage("Liên hệ", listOf("Nguyễn Văn Minh", "Trần Thị Hoa", "Lê Quốc Bảo", "Phạm Thị Lan"))
}

@Composable
fun Account() {
    SimplePage("Tài khoản", listOf("Đơn hàng của tôi", "Tin đã đăng", "Sản phẩm yêu thích", "Cài đặt tài khoản", "Hỗ trợ khách hàng"))
}

@Composable
fun SimplePage(title: String, rows: List<String>) {
    Column(Modifier.fillMaxSize().background(Bg)) {
        Top(title)
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            rows.forEach { row ->
                Card(
                    Modifier.fillMaxWidth().clickable {},
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = White)
                ) {
                    Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(row, Modifier.weight(1f), fontWeight = FontWeight.Medium, color = TextDark)
                        Icon(Icons.Default.ChevronRight, null, tint = Muted)
                    }
                }
            }
        }
    }
}
