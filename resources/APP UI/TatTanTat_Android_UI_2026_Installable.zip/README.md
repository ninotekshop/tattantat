# Tất Tần Tật – Android UI Starter (2026)

Bộ source giao diện Android Jetpack Compose cho ứng dụng **Tất Tần Tật**.

## Đã cập nhật theo thiết kế mới
- Header màu xanh đậm, tách biệt rõ với nội dung.
- Logo Tất Tần Tật dùng asset logo đã cung cấp.
- Thanh navigation dưới dùng cùng hệ màu xanh đậm của header.
- Nút trung tâm **Đăng tin +** dùng xanh thương hiệu, không dùng vàng.
- Nút **Trang chủ** khi active dùng xanh thương hiệu.
- Form tìm kiếm nổi bật ngay đầu màn hình.
- Danh mục dạng icon, cuộn ngang.
- Trang chủ hiển thị sản phẩm dạng lưới 2 cột.
- Có các màn hình mẫu: Trang chủ, Quản lý tin, Đăng tin, Liên hệ, Tài khoản.

## Chạy thử
1. Mở thư mục này bằng Android Studio.
2. Chờ Gradle Sync hoàn tất.
3. Chọn emulator hoặc điện thoại Android thật.
4. Bấm Run.

## Công nghệ
- Kotlin
- Jetpack Compose
- Material 3
- Android SDK 35
- Min SDK 24

## Lưu ý
Đây là bộ **UI/frontend starter**, chưa kết nối API, PostgreSQL, OTP, đăng nhập thật,
upload ảnh, chat realtime, thanh toán hoặc hệ thống quảng cáo.

Bước tiếp theo có thể nối UI này vào backend PostgreSQL/API của dự án Tất Tần Tật.
